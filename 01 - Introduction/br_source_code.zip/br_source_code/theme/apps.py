from django.apps import AppConfig


class ThemeConfig(AppConfig):
    name = 'theme'
